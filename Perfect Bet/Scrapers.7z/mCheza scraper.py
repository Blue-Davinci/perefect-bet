'''
'''

import requests
from bs4 import BeautifulSoup
import pandas as pd

file = "C:\\Users\\Blue_Davinci\\Downloads\\Sites\\mCHEZA.html"

with open(file,'rb') as fp:
    soup = BeautifulSoup(fp,'html.parser')

games = soup.find_all("div",{"class":"matches-set"})
team1Names = []
team1Odds = []
teamDraw = []
team2Names = []
team2Odds =[]
for elem in games[1]:
    y = elem.find("div",{"class":"match-teams"}).get_text()
    if y != None:
        team1Names.append(y.split(" v ")[0])
        team2Names.append(y.split(" v ")[1])
    draw = elem.find("div",{"class":"selection-button selection-button-X"}).get_text()
    if draw != None:
        teamDraw.append(draw)
    odd1 = elem.find("div",{"class":"selection-button selection-button-1"}).get_text()
    if odd1 != None:
        team1Odds.append(odd1)

    odd2 =elem.find("div",{"class":"selection-button selection-button-2"}).get_text()
    if odd2 != None:
        team2Odds.append(odd2)


teamTable = pd.DataFrame({
    "T1": team1Names,
    "T1 odd": team1Odds,
    "M.Draw": teamDraw,
    "T2": team2Names,
    "T2 Odd": team2Odds
})
pd.set_option('display.expand_frame_repr', False)
print("\t ================================ M-Cheza ==============================")
print(teamTable)